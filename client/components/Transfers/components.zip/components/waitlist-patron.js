import React, { Component } from 'react';

class WaitListPatron extends Component {
	
	renderList() {
		const { patron, cell } = this.props;

			return (
				<div>
				<td> { patron } </td>
				<td> { cell } </td>
				</div>
			);
	}

	renderAction() {
		return ( 
			<td>
			<button onClick = {this.props.deletePatron.bind(this, this.props.patron)}> Delete </button> 
			</td>
		);
	}

	render() {
    return (
      <tr>
        {this.renderList()}
        {this.renderAction()}
      </tr>
    );
  }

}

export default WaitListPatron;